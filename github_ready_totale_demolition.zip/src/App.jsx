export default function App() {
  return <h1>Totale Demolition — Ready for GitHub</h1>
}
